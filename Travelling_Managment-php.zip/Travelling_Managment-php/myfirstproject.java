class myfirstproject{
    public static void main (string[]args)
    int a=5 ;
    int b=a++;
    system.out.println(a"   " +b);
}